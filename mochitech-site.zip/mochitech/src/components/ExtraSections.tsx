import { useState } from "react";
import { BatteryCharging, Clock, CookingPot, MapPin, Star, Sun, Umbrella, Moon } from "lucide-react";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { PRODUCT } from "@/lib/product";
import mochilaGrafite from "@/assets/mochitech-hero.jpg";
import mochilaBranca from "@/assets/mochila-branca.jpg";
import mochilaAzul from "@/assets/mochila-azul.jpg";
import mochilaVermelha from "@/assets/mochila-vermelha.jpg";
import garrafaGrafite from "@/assets/garrafa-termica.jpg";
import garrafaBranca from "@/assets/garrafa-branca.jpg";
import garrafaAzul from "@/assets/garrafa-azul.jpg";
import garrafaVermelha from "@/assets/garrafa-vermelha.jpg";

const COLORS = [
  { name: "Grafite Noturno", swatch: "bg-swatch-grafite", mochila: mochilaGrafite, garrafa: garrafaGrafite },
  { name: "Branco Ártico", swatch: "bg-swatch-branco", mochila: mochilaBranca, garrafa: garrafaBranca },
  { name: "Azul Oceano", swatch: "bg-swatch-azul", mochila: mochilaAzul, garrafa: garrafaAzul },
  { name: "Vermelho Rubi", swatch: "bg-swatch-vermelho", mochila: mochilaVermelha, garrafa: garrafaVermelha },
];

function Kicker({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">{children}</p>
  );
}

export function Colors() {
  const [active, setActive] = useState(0);
  const c = COLORS[active] ?? COLORS[0]!;
  return (
    <section id="cores" className="relative py-28">
      <div className="absolute inset-0 bg-glow-radial" aria-hidden />
      <div className="relative mx-auto max-w-6xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Kicker>Cores</Kicker>
          <h2 className="mt-4 text-3xl font-bold sm:text-5xl">Escolha o seu estilo</h2>
          <p className="mt-4 text-muted-foreground">
            A mochila e a garrafa térmica vêm sempre na mesma cor. 4 opções para combinar com você.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-3">
          {COLORS.map((color, i) => (
            <button
              key={color.name}
              onClick={() => setActive(i)}
              aria-pressed={i === active}
              className={`flex items-center gap-3 rounded-full border px-4 py-2 text-sm font-semibold transition-all ${
                i === active
                  ? "border-primary bg-primary/10 text-primary shadow-glow"
                  : "border-border text-muted-foreground hover:border-primary/50"
              }`}
            >
              <span className={`h-5 w-5 rounded-full border border-border ${color.swatch}`} />
              {color.name}
            </button>
          ))}
        </div>

        <div className="mt-12 grid items-end gap-6 md:grid-cols-[1.6fr_1fr]">
          <figure className="overflow-hidden rounded-[2.5rem] border border-border glass-card">
            <img
              key={c.mochila}
              src={c.mochila}
              alt={`Mochila Mochitech na cor ${c.name}`}
              width={1280}
              height={1280}
              loading="lazy"
              className="aspect-square w-full object-cover animate-in fade-in duration-500"
            />
            <figcaption className="flex justify-between p-5 text-sm">
              <span className="font-display font-bold">Mochila {PRODUCT.name}</span>
              <span className="text-muted-foreground">{c.name}</span>
            </figcaption>
          </figure>
          <figure className="overflow-hidden rounded-[2.5rem] border border-border glass-card">
            <img
              key={c.garrafa}
              src={c.garrafa}
              alt={`Garrafa térmica na cor ${c.name}`}
              width={1024}
              height={1280}
              loading="lazy"
              className="aspect-[4/5] w-full object-cover animate-in fade-in duration-500"
            />
            <figcaption className="flex justify-between p-5 text-sm">
              <span className="font-display font-bold">Garrafa térmica</span>
              <span className="text-muted-foreground">{c.name}</span>
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  );
}

const DAY = [
  { icon: Sun, time: "07:00", title: "Bom dia", text: "A MochIA avisa o clima e confere a bateria do powerbank." },
  { icon: MapPin, time: "08:00", title: "No caminho", text: "GPS ativo: rotas e localização da mochila em tempo real." },
  { icon: CookingPot, time: "12:00", title: "Almoço", text: "Sua marmita já está quentinha no compartimento aquecedor." },
  { icon: Umbrella, time: "18:00", title: "Começou a chover", text: "O guarda-chuva automático abre sozinho." },
  { icon: Moon, time: "21:00", title: "Em casa", text: "Recarregue a mochila e a garrafa para o próximo dia." },
];

export function DayTimeline() {
  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Kicker>Um dia com a {PRODUCT.name}</Kicker>
          <h2 className="mt-4 text-3xl font-bold sm:text-5xl">{PRODUCT.slogan}, do começo ao fim</h2>
        </div>
        <div className="mt-16 grid gap-4 md:grid-cols-5">
          {DAY.map(({ icon: Icon, time, title, text }) => (
            <div key={time} className="relative rounded-3xl glass-card p-6">
              <div className="flex items-center justify-between">
                <Icon className="h-6 w-6 text-primary" />
                <span className="flex items-center gap-1 font-display text-sm font-bold text-heat">
                  <Clock className="h-3.5 w-3.5" />
                  {time}
                </span>
              </div>
              <h3 className="mt-5 text-base font-bold">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

const SPECS: [string, string][] = [
  ["Capacidade", "28 litros"],
  ["Powerbank", "20.000 mAh, 2 USB-C + 1 USB-A"],
  ["Autonomia", "Até 3 dias de uso"],
  ["Aquecedor de marmitas", "Até 70°C"],
  ["Garrafa térmica", "750 ml, com aquecimento"],
  ["Conectividade", "Bluetooth 5.3 e GPS"],
  ["Material", "Tecido impermeável"],
  ["Peso", "1,9 kg"],
];

export function Specs() {
  return (
    <section id="especificacoes" className="relative py-28">
      <div className="mx-auto grid max-w-6xl gap-12 px-6 lg:grid-cols-[1fr_1.4fr]">
        <div>
          <Kicker>Ficha técnica</Kicker>
          <h2 className="mt-4 text-3xl font-bold sm:text-5xl">Tudo nos detalhes</h2>
          <p className="mt-4 text-muted-foreground">
            Feita pela {PRODUCT.company} para aguentar a sua rotina, faça sol ou chuva.
          </p>
          <div className="mt-8 flex items-center gap-3 rounded-3xl glass-card p-5">
            <BatteryCharging className="h-8 w-8 text-primary" />
            <p className="text-sm text-muted-foreground">
              Carregue a mochila inteira com um único cabo USB-C.
            </p>
          </div>
        </div>
        <dl className="divide-y divide-border rounded-[2rem] glass-card px-6">
          {SPECS.map(([k, v]) => (
            <div key={k} className="flex justify-between gap-4 py-4 text-sm">
              <dt className="text-muted-foreground">{k}</dt>
              <dd className="text-right font-semibold">{v}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}

const REVIEWS = [
  { name: "Ana, estudante", text: "O guarda-chuva automático salvou meu notebook. E almoçar comida quente na faculdade é outra vida!" },
  { name: "Rafael, motoboy", text: "O powerbank segura meu celular o dia inteiro, e o GPS me dá segurança." },
  { name: "Juliana, designer", text: "Peguei a Branco Ártico. Linda, e a MochIA lembra de tudo por mim." },
];

export function Reviews() {
  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Kicker>Quem usa, aprova</Kicker>
          <h2 className="mt-4 text-3xl font-bold sm:text-5xl">O que dizem por aí</h2>
        </div>
        <div className="mt-14 grid gap-4 md:grid-cols-3">
          {REVIEWS.map((r) => (
            <figure key={r.name} className="rounded-3xl glass-card p-7">
              <div className="flex gap-1 text-heat">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <blockquote className="mt-4 text-sm leading-relaxed">“{r.text}”</blockquote>
              <figcaption className="mt-5 text-sm font-semibold text-primary">{r.name}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

const FAQ: [string, string][] = [
  ["A mochila é à prova d'água?", "Sim, o tecido é impermeável e ainda conta com o guarda-chuva automático."],
  ["Posso lavar a mochila?", "Sim, basta retirar o módulo eletrônico e lavar à mão."],
  ["A garrafa térmica vem junto?", `Sim! Toda ${PRODUCT.name} vem com a garrafa térmica especial na mesma cor.`],
  [`A ${PRODUCT.aiName} funciona sem internet?`, "Os comandos básicos funcionam offline; clima e rotas usam a internet do seu celular via Bluetooth."],
  ["Quanto tempo leva para esquentar a marmita?", "Em média 15 a 20 minutos, e você pode programar o horário."],
];

export function Faq() {
  return (
    <section id="duvidas" className="relative py-28">
      <div className="mx-auto max-w-3xl px-6">
        <div className="text-center">
          <Kicker>Dúvidas</Kicker>
          <h2 className="mt-4 text-3xl font-bold sm:text-5xl">Perguntas frequentes</h2>
        </div>
        <Accordion type="single" collapsible className="mt-12 rounded-[2rem] glass-card px-6">
          {FAQ.map(([q, a]) => (
            <AccordionItem key={q} value={q}>
              <AccordionTrigger className="text-left text-base font-semibold">{q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
