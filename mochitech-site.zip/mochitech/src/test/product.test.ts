import { describe, expect, it } from "vitest";

import { PRODUCT, formatBRL } from "@/lib/product";

describe("Mochitech product facts", () => {
  it("costs R$ 2.398,00", () => {
    expect(formatBRL(PRODUCT.price).replace(/\s/g, " ")).toBe("R$ 2.398,00");
  });

  it("uses the slogan 'Seu dia mais tech'", () => {
    expect(PRODUCT.slogan).toBe("Seu dia mais tech");
  });

  it("uses the tagline 'A tecnologia nas suas costas'", () => {
    expect(PRODUCT.tagline).toBe("A tecnologia nas suas costas");
  });
});
