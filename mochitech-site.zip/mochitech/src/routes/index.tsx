import { createFileRoute } from "@tanstack/react-router";
import {
  BatteryCharging,
  Bluetooth,
  CookingPot,
  CupSoda,
  MapPin,
  ShieldCheck,
  Sparkles,
  Thermometer,
  Truck,
  Umbrella,
  Wifi,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { PRODUCT, formatBRL } from "@/lib/product";
import { Colors, DayTimeline, Faq, Reviews, Specs } from "@/components/ExtraSections";
import heroImg from "@/assets/mochitech-hero.jpg";
import logoImg from "@/assets/mochitech-logo.png";
import garrafaImg from "@/assets/garrafa-termica.jpg";
import chuvaImg from "@/assets/guarda-chuva.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mochitech — Seu dia mais tech | Fourtech" },
      {
        name: "description",
        content:
          "Mochitech: mochila tecnológica com powerbank, IA MochIA, GPS, guarda-chuva automático, aquecedor de marmita e garrafa térmica. Por R$ 2.398,00.",
      },
      { property: "og:title", content: "Mochitech — A tecnologia nas suas costas" },
      {
        property: "og:description",
        content: "A mochila tecnológica da Fourtech. Seu dia mais tech por R$ 2.398,00.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const FEATURES = [
  {
    icon: BatteryCharging,
    title: "Powerbank integrado",
    text: "Carregue celular, fone e notebook em qualquer lugar, direto pela mochila.",
  },
  {
    icon: Sparkles,
    title: `IA ${PRODUCT.aiName}`,
    text: "Sua assistente pessoal: lembretes, rotas, clima e controle de todas as funções por voz.",
  },
  {
    icon: Bluetooth,
    title: "Bluetooth",
    text: "Conecte seu celular e controle a mochila pelo app, sem fios.",
  },
  {
    icon: Umbrella,
    title: "Guarda-chuva automático",
    text: "Detectou chuva? Ele abre sozinho e protege você.",
  },
  {
    icon: CookingPot,
    title: "Aquecedor de marmitas",
    text: "Compartimento térmico que esquenta sua comida onde você estiver.",
  },
  {
    icon: Thermometer,
    title: "Controle de temperatura",
    text: "Ajuste a temperatura dos compartimentos para manter tudo no ponto.",
  },
  {
    icon: MapPin,
    title: "GPS",
    text: "Localização em tempo real. Nunca perca sua mochila de vista.",
  },
  {
    icon: CupSoda,
    title: "Garrafa térmica especial",
    text: "Acompanha a mochila e tem compartimento próprio para esquentar.",
  },
];

function Index() {
  return (
    <div className="relative overflow-x-hidden">
      <Header />
      <main>
        <Hero />
        <Features />
        <Colors />
        <MochIA />
        <Rain />
        <Heat />
        <DayTimeline />
        <Specs />
        <Brand />
        <Reviews />
        <Buy />
        <Faq />
      </main>
      <Footer />
    </div>
  );
}

function Logo({ size = 40 }: { size?: number }) {
  return (
    <img
      src={logoImg}
      alt="Logomarca Mochitech"
      width={size}
      height={size}
      style={{ width: size, height: size }}
    />
  );
}

function Header() {
  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div className="mx-auto mt-4 flex max-w-6xl items-center justify-between rounded-full glass-card px-4 py-2 sm:px-6">
        <a href="#topo" className="flex items-center gap-2">
          <Logo size={36} />
          <span className="font-display text-lg font-bold tracking-tight">{PRODUCT.name}</span>
        </a>
        <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
          <a href="#recursos" className="transition-colors hover:text-primary">
            Recursos
          </a>
          <a href="#mochia" className="transition-colors hover:text-primary">
            {PRODUCT.aiName}
          </a>
          <a href="#garrafa" className="transition-colors hover:text-primary">
            Garrafa
          </a>
          <a href="#comprar" className="transition-colors hover:text-primary">
            Preço
          </a>
        </nav>
        <Button variant="hero" size="sm" asChild className="px-5">
          <a href="#comprar">Comprar</a>
        </Button>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="topo" className="relative min-h-screen pt-32 pb-20">
      <div className="absolute inset-0 bg-grid" aria-hidden />
      <div className="absolute inset-0 bg-glow-radial" aria-hidden />
      <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-6 lg:grid-cols-2">
        <div className="animate-in fade-in slide-in-from-bottom-6 duration-700">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            {PRODUCT.tagline}
          </span>
          <h1 className="mt-6 text-5xl font-extrabold leading-[1.02] sm:text-6xl lg:text-7xl">
            <span className="text-gradient">{PRODUCT.slogan}</span>
          </h1>
          <p className="mt-6 max-w-lg text-lg text-muted-foreground">
            Conheça a <strong className="text-foreground">{PRODUCT.name}</strong>: energia,
            inteligência artificial, GPS, guarda-chuva automático e até um aquecedor de marmitas.
            Tudo em uma só mochila.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Button variant="hero" size="xl" asChild>
              <a href="#comprar">Quero a minha</a>
            </Button>
            <Button variant="glass" size="xl" asChild>
              <a href="#recursos">Ver recursos</a>
            </Button>
          </div>
          <div className="mt-10 flex items-end gap-3">
            <span className="text-sm text-muted-foreground">por apenas</span>
            <span className="font-display text-3xl font-bold text-primary">
              {formatBRL(PRODUCT.price)}
            </span>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-lg">
          <div className="absolute inset-8 rounded-full bg-primary/20 blur-3xl" aria-hidden />
          <div
            className="absolute inset-0 rounded-full border border-primary/30 animate-pulse-ring"
            aria-hidden
          />
          <img
            src={heroImg}
            alt="Mochila Mochitech com luzes de LED azuis"
            width={1280}
            height={1280}
            className="relative animate-float rounded-[2.5rem] border border-border shadow-glow-lg"
          />
          <FloatingChip className="-left-4 top-10" icon={BatteryCharging} label="Bateria 100%" />
          <FloatingChip className="-right-4 top-1/3" icon={MapPin} label="GPS ativo" />
          <FloatingChip className="bottom-10 left-6" icon={Thermometer} label="Marmita 65°C" heat />
        </div>
      </div>
    </section>
  );
}

function FloatingChip({
  className,
  icon: Icon,
  label,
  heat,
}: {
  className: string;
  icon: typeof Wifi;
  label: string;
  heat?: boolean;
}) {
  return (
    <div
      className={`absolute hidden items-center gap-2 rounded-full glass-card px-4 py-2 text-sm font-semibold sm:flex ${className}`}
    >
      <Icon className={heat ? "h-4 w-4 text-heat" : "h-4 w-4 text-primary"} />
      {label}
    </div>
  );
}

function SectionTitle({ kicker, title, text }: { kicker: string; title: string; text?: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">{kicker}</p>
      <h2 className="mt-4 text-3xl font-bold sm:text-5xl">{title}</h2>
      {text && <p className="mt-4 text-muted-foreground">{text}</p>}
    </div>
  );
}

function Features() {
  return (
    <section id="recursos" className="relative py-28">
      <div className="mx-auto max-w-6xl px-6">
        <SectionTitle
          kicker="Recursos"
          title="8 tecnologias, 1 mochila"
          text="Tudo o que você precisa no seu dia, pensado para facilitar sua rotina."
        />
        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map(({ icon: Icon, title, text }) => (
            <div
              key={title}
              className="group rounded-3xl glass-card p-6 transition-all hover:-translate-y-1 hover:border-primary/50 hover:shadow-glow"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <Icon className="h-6 w-6" />
              </div>
              <h3 className="mt-5 text-base font-bold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function MochIA() {
  const messages = [
    { from: "user", text: "MochIA, vai chover hoje?" },
    {
      from: "ai",
      text: "Sim, 80% de chance às 18h. Deixei o guarda-chuva automático pronto para abrir.",
    },
    { from: "user", text: "Esquenta minha marmita para o meio-dia." },
    { from: "ai", text: "Feito! Sua comida estará a 65°C às 12h00. Bom almoço! 🍱" },
  ];
  return (
    <section id="mochia" className="relative py-28">
      <div className="absolute inset-0 bg-glow-radial" aria-hidden />
      <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-6 lg:grid-cols-2">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
            Inteligência artificial
          </p>
          <h2 className="mt-4 text-3xl font-bold sm:text-5xl">
            Conheça a <span className="text-primary">{PRODUCT.aiName}</span>
          </h2>
          <p className="mt-5 text-lg text-muted-foreground">
            A IA que mora na sua mochila. Converse por voz ou pelo app via Bluetooth e controle a
            temperatura, o aquecedor, o GPS e o guarda-chuva — ela aprende com a sua rotina.
          </p>
          <ul className="mt-8 space-y-3 text-sm">
            {[
              "Comandos por voz em português",
              "Avisos de bateria, clima e trânsito",
              "Localização da mochila em tempo real",
            ].map((item) => (
              <li key={item} className="flex items-center gap-3">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/15 text-primary">
                  <Sparkles className="h-3.5 w-3.5" />
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-[2rem] glass-card p-6 shadow-glow">
          <div className="flex items-center gap-3 border-b border-border pb-4">
            <div className="relative flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <p className="font-display text-sm font-bold">{PRODUCT.aiName}</p>
              <p className="text-xs text-primary">● online</p>
            </div>
          </div>
          <div className="mt-5 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={m.from === "user" ? "flex justify-end" : "flex"}>
                <p
                  className={
                    m.from === "user"
                      ? "max-w-[80%] rounded-2xl rounded-br-sm bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground"
                      : "max-w-[80%] rounded-2xl rounded-bl-sm bg-secondary px-4 py-2.5 text-sm"
                  }
                >
                  {m.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Rain() {
  return (
    <section className="relative py-12">
      <div className="mx-auto max-w-6xl px-6">
        <div className="relative overflow-hidden rounded-[2.5rem] border border-border">
          <img
            src={chuvaImg}
            alt="Pessoa andando na chuva protegida pelo guarda-chuva automático da Mochitech"
            width={1536}
            height={1024}
            loading="lazy"
            className="h-[520px] w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent" />
          <div className="absolute inset-y-0 left-0 flex max-w-md flex-col justify-center p-8 sm:p-12">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-glow">
              <Umbrella className="h-7 w-7" />
            </div>
            <h2 className="mt-6 text-3xl font-bold sm:text-4xl">Choveu? Ela abre sozinha.</h2>
            <p className="mt-4 text-muted-foreground">
              Sensores detectam a chuva e o guarda-chuva automático se abre na hora, deixando suas
              mãos livres e você seco.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Heat() {
  return (
    <section id="garrafa" className="relative py-28">
      <div className="absolute inset-0 bg-glow-heat" aria-hidden />
      <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-6 lg:grid-cols-2">
        <div className="relative mx-auto w-full max-w-sm">
          <div className="absolute inset-10 rounded-full bg-heat/25 blur-3xl" aria-hidden />
          <img
            src={garrafaImg}
            alt="Garrafa térmica especial Mochitech com compartimento aquecedor"
            width={1024}
            height={1280}
            loading="lazy"
            className="relative rounded-[2.5rem] border border-border shadow-heat"
          />
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-heat">
            Comida e bebida quentinhas
          </p>
          <h2 className="mt-4 text-3xl font-bold sm:text-5xl">
            Almoço quente, <span className="text-heat">em qualquer lugar</span>
          </h2>
          <p className="mt-5 text-lg text-muted-foreground">
            Um compartimento da Mochitech tem uma máquina que esquenta marmitas. E junto vem a
            garrafa térmica especial, com seu próprio compartimento aquecedor.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            <div className="rounded-3xl glass-card p-5">
              <CookingPot className="h-6 w-6 text-heat" />
              <p className="mt-3 font-display text-sm font-bold">Aquecedor de marmitas</p>
              <p className="mt-1 text-sm text-muted-foreground">Esquenta sua comida na mochila.</p>
            </div>
            <div className="rounded-3xl glass-card p-5">
              <CupSoda className="h-6 w-6 text-heat" />
              <p className="mt-3 font-display text-sm font-bold">Garrafa térmica inclusa</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Com compartimento para esquentar.
              </p>
            </div>
            <div className="rounded-3xl glass-card p-5 sm:col-span-2">
              <Thermometer className="h-6 w-6 text-heat" />
              <p className="mt-3 font-display text-sm font-bold">Controle de temperatura</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Escolha a temperatura ideal pelo app ou pedindo para a {PRODUCT.aiName}.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Brand() {
  const symbols = [
    { icon: Wifi, label: "Wi-Fi" },
    { icon: Bluetooth, label: "Bluetooth" },
    { icon: MapPin, label: "GPS" },
    { icon: BatteryCharging, label: "Bateria" },
  ];
  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <div className="relative mx-auto h-56 w-56">
          <div className="absolute inset-0 rounded-full bg-primary/15 blur-3xl" aria-hidden />
          <img
            src={logoImg}
            alt="Logomarca Mochitech: mochila com símbolos de Wi-Fi, Bluetooth, GPS e bateria"
            width={1024}
            height={1024}
            loading="lazy"
            className="relative h-full w-full"
          />
        </div>
        <h2 className="mt-8 text-4xl font-extrabold sm:text-6xl">
          <span className="text-gradient">{PRODUCT.tagline}</span>
        </h2>
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          {symbols.map(({ icon: Icon, label }) => (
            <span
              key={label}
              className="inline-flex items-center gap-2 rounded-full glass-card px-4 py-2 text-sm"
            >
              <Icon className="h-4 w-4 text-primary" />
              {label}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

function Buy() {
  return (
    <section id="comprar" className="relative py-28">
      <div className="mx-auto max-w-5xl px-6">
        <div className="relative overflow-hidden rounded-[2.5rem] border border-primary/30 bg-card p-8 shadow-glow sm:p-14">
          <div className="absolute inset-0 bg-glow-radial" aria-hidden />
          <div className="relative grid items-center gap-10 md:grid-cols-[1.2fr_1fr]">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
                {PRODUCT.slogan}
              </p>
              <h2 className="mt-4 text-3xl font-bold sm:text-5xl">
                Garanta sua {PRODUCT.name}
              </h2>
              <ul className="mt-6 grid gap-2 text-sm text-muted-foreground sm:grid-cols-2">
                {[
                  "Powerbank",
                  `IA ${PRODUCT.aiName}`,
                  "Bluetooth e GPS",
                  "Guarda-chuva automático",
                  "Aquecedor de marmitas",
                  "Garrafa térmica inclusa",
                ].map((i) => (
                  <li key={i} className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                    {i}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-3xl glass-card p-8 text-center">
              <p className="text-sm text-muted-foreground">Preço</p>
              <p className="mt-2 font-display text-4xl font-extrabold text-primary sm:text-5xl">
                {formatBRL(PRODUCT.price)}
              </p>
              <Button variant="hero" size="xl" className="mt-6 w-full">
                Comprar agora
              </Button>
              <div className="mt-5 flex justify-center gap-5 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Truck className="h-4 w-4" /> Entrega Brasil
                </span>
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4" /> Garantia
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 text-sm text-muted-foreground sm:flex-row">
        <div className="flex items-center gap-2">
          <Logo size={28} />
          <span className="font-display font-bold text-foreground">{PRODUCT.name}</span>
          <span>— {PRODUCT.slogan}</span>
        </div>
        <p>
          Um produto <span className="font-semibold text-foreground">{PRODUCT.company}</span> ©{" "}
          {new Date().getFullYear()}
        </p>
      </div>
    </footer>
  );
}
