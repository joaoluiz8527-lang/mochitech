export const PRODUCT = {
  name: "Mochitech",
  company: "Fourtech",
  slogan: "Seu dia mais tech",
  tagline: "A tecnologia nas suas costas",
  aiName: "MochIA",
  price: 2398,
} as const;

export function formatBRL(value: number): string {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);
}
